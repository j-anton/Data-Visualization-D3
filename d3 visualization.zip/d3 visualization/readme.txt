1)  Start a local web server. In this directory: 
		% python -m SimpleHTTPServer port 8000

2)  In browser go to: localhost:8000/project_v5.html
